//
//  ViewController.swift
//  UIKit_Class
//
//  Created by Sagar Midha on 15/07/25.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var chitkaraLabel: UILabel!
    // properties will define here above viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func wifiSwitch(_ sender: UISwitch) {
        if sender.isOn {
            print("wifi is on")
        }
        else {
            print("wifi is off")
        }
    }

    @IBAction func button(_ sender: UIButton) {
        print("button is tapped")
        chitkaraLabel.text = "iOS Developer"
    }
    @IBAction func Volumechnge(_ sender: UISlider) {
        print(sender.value)
    }
    @IBAction func textwritten(_ sender: UITextField) {
        if let text = sender.text {
            print(text)
        }
    }
        // and here are the methods
}

