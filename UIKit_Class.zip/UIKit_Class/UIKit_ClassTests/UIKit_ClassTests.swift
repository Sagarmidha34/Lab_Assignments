//
//  UIKit_ClassTests.swift
//  UIKit_ClassTests
//
//  Created by Sagar Midha on 15/07/25.
//

import Testing
@testable import UIKit_Class

struct UIKit_ClassTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
