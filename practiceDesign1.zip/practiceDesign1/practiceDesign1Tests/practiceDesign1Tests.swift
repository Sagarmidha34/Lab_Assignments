//
//  practiceDesign1Tests.swift
//  practiceDesign1Tests
//
//  Created by Sagar Midha on 15/07/25.
//

import Testing
@testable import practiceDesign1

struct practiceDesign1Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
