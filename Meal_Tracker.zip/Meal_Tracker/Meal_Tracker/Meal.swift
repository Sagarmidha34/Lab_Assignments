//
//  Meal.swift
//  Meal_Tracker
//
//  Created by Sagar Midha on 18/08/25.
//

import Foundation
struct Meal {
    var name: String
    var food : [Food]
}
