//
//  Food.swift
//  Meal_Tracker
//
//  Created by Sagar Midha on 18/08/25.
//

import Foundation
struct Food{
    var name : String
    var description : String
}
