//
//  Meal_TrackerTests.swift
//  Meal_TrackerTests
//
//  Created by Sagar Midha on 18/08/25.
//

import Testing
@testable import Meal_Tracker

struct Meal_TrackerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
