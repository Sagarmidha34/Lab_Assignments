//
//  ViewController.swift
//  Lab_BasicInteraction
//
//  Created by Sagar Midha on 16/07/25.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textFeild: UITextField!
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func setTextButtonTapped(_ sender: UIButton) {
        label.text = textFeild.text
    }
    @IBAction func clearTextButtonTapped(_ sender: UIButton) {
        textFeild.text = ""
        label.text = ""
    }

}

